<?php


	 
        $db = getDB();
        $userData ='';
        $sql = "SELECT user_id, name, email, username FROM users WHERE (username=:username or email=:username) and password=:password ";
        $stmt = $db->prepare($sql);
        $stmt->bindParam("username", $data->username, PDO::PARAM_STR);
        $password=hash('sha256',$data->password);
        $stmt->bindParam("password", $password, PDO::PARAM_STR);
        $stmt->execute();
        $mainCount=$stmt->rowCount();
        $userData = $stmt->fetch(PDO::FETCH_OBJ);
        
 ______________________________-----------signin()----------------------___________________
        $db = getDB();
        $userData ='';
        $sql = "SELECT id_user,login_user,nom_user, prenom_user,emailPerso_user,emailPro_user,
		mdp_user,fonction_user,tel_user,questSecr_user,repSecr_user,id_statut 
		FROM utilisateur WHERE (login_user=:login_user or email=:login_user)and mdp_user=:mdp_user ";
        $stmt = $db->prepare($sql);
        $stmt->bindParam("login_user", $data->login_user, PDO::PARAM_STR);
        $mdp_user=hash('sha256',$data->mdp_user);
        $stmt->bindParam("mdp_user", mdp_user, PDO::PARAM_STR);
        $stmt->execute();
        $mainCount=$stmt->rowCount();
        $userData = $stmt->fetch(PDO::FETCH_OBJ);
		
		
		
		-------____________---------
        
_________________________________----------class.auth--------------_________________________________------------------------_

$req = $PDO->prepare('SELECT C.id_collabo, C.nom_collabo, 
										 C.prenom_collabo, C.login_collabo, C.emailPers_collabo, C.emailPro_collabo,
										 C.fonction_collabo, C.port_collabo, C.tel_collabo, C.adr_collabo,
										 S.nom, S.slug, S.niveau
								  FROM collaborateur C, statut S
								  WHERE C.id_statut = S.id_statut
								  AND C.login_collabo=:login 
								  AND C.mdp_collabo =:password');
								  
 
								  
------------------------------------___________________________------------------

$req = $PDO->prepare('SELECT T.id_user,T.login_user,T.nom_user, T.prenom_user,T.emailPerso_user,T.emailPro_user,
		T.mdp_user,T.fonction_user,T.tel_user,T.questSecr_user,T.repSecr_user,T.id_statut 
		FROM utilisateur T, statut S 
		WHERE T.id_statut = S.id_statut
		AND (T.login_user=:login_user or T.email=:login_user)
		AND T.mdp_user=:mdp_user ');

?>
______________________________________________________
$sql = "SELECT U.user_id, U.name,U.email,U.username 
				FROM users U, emailusers E 
				WHERE U.email = E.email 
				and (U.sername=:username or U.email=:username) 
				and password=:password ";
______________________________________________________

<?php
require 'config.php';
require 'Slim/Slim.php';

\Slim\Slim::registerAutoloader();
$app = new \Slim\Slim();

$app->post('/login','login'); /* User login */
$app->post('/signup','signup'); /* User Signup  */

$app->run();

/************************* USER LOGIN *************************************/
/* ### User login ### */
function login() {
    
    $request = \Slim\Slim::getInstance()->request();
    $data = json_decode($request->getBody());
    
    try {
        
        $db = getDB();
        $userData ='';
        $sql = "SELECT id_user,login_user,nom_user, prenom_user,emailPerso_user,emailPro_user,
		mdp_user,fonction_user,tel_user,questSecr_user,repSecr_user,id_statut 
		FROM utilisateur WHERE (login_user=:login_user or emailPro_user=:login_user)and mdp_user=:mdp_user ";
        $stmt = $db->prepare($sql);
        $stmt->bindParam("login_user", $data->login_user, PDO::PARAM_STR);
        $mdp_user=hash('sha256',$data->mdp_user);
        $stmt->bindParam("mdp_user", mdp_user, PDO::PARAM_STR);
        $stmt->execute();
        $mainCount=$stmt->rowCount();
        $userData = $stmt->fetch(PDO::FETCH_OBJ);
        
        if(!empty($userData))
        {
            $id_user=$userData->id_user;
            $userData->token = apiToken($id_user);
        }
        
        $db = null;
         if($userData){
               $userData = json_encode($userData);
                echo '{"userData": ' .$userData . '}';
            } else {
               echo '{"error":{"text":"Bad request wrong login_user and mdp_user"}}';
            }

           
    }
    catch(PDOException $e) {
        echo '{"error":{"text":'. $e->getMessage() .'}}';
    }
}


/* ### User registration ### */
function signup() {
    $request = \Slim\Slim::getInstance()->request();
    $data = json_decode($request->getBody());
    $emailPerso_user=$data->emailPerso_user;
	$emailPro_user=$data->emailPro_user;
    $nom_user=$data->nom_user;
    $login_user=$data->login_user;
    $mdp_user=$data->mdp_user;
    
    try {
        
        $login_user_check = preg_match('~^[A-Za-z0-9_]{3,20}$~i', $login_user);
		$emailPerso_user_check = preg_match('~^[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.([a-zA-Z]{2,4})$~i', $emailPerso_user);
        $emailPro_user_check = preg_match('~^[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.([a-zA-Z]{2,4})$~i', $emailPro_user);
        $mdp_user_check = preg_match('~^[A-Za-z0-9!@#$%^&*()_]{6,20}$~i', $mdp_user);
        
        echo $emailPro_user_check.'<br/>'.$emailPro_user;
        
        if (strlen(trim($login_user))>0&&strlen(trim($mdp_user))>0&&strlen(trim($emailPerso_user))>0&&strlen(trim($emailPro_user))>0&&$emailPerso_user_check>0&&$emailPro_user_check>0&&$login_user_check>0&&$mdp_user_check>0)
        {
            //echo 'here';
            $db = getDB();
            $userData = '';
            $sql = "SELECT id_user FROM utilisateur WHERE login_user=:login_user or emailPro_user=:login_user";
            $stmt = $db->prepare($sql);
            $stmt->bindParam("login_user", $login_user,PDO::PARAM_STR);
            $stmt->bindParam("emailPro_user", $emailPro_user,PDO::PARAM_STR);
            $stmt->execute();
            $mainCount=$stmt->rowCount();
            $created=time();
            if($mainCount==0)
            {
                
                /*Inserting user values*/
                $sql1="INSERT INTO utilisateur(login_user,nom_user,prenom_user,emailPerso_user,emailPro_user,
		mdp_user,fonction_user,tel_user,questSecr_user,repSecr_user,id_statut)
		VALUES(:login_user,:nom_user,:prenom_user,:emailPerso_user,:emailPro_user,:mdp_user,:fonction_user,:tel_user,:questSecr_user,:repSecr_user,:id_statut)";
                $stmt1 = $db->prepare($sql1);
                $stmt1->bindParam("login_user", $login_user,PDO::PARAM_STR);
				$stmt1->bindParam("nom_user", $nom_user,PDO::PARAM_STR);
				$stmt1->bindParam("prenom_user", $prenom_user,PDO::PARAM_STR);
				$stmt1->bindParam("emailPerso_user", $emailPerso_user,PDO::PARAM_STR);
				$stmt1->bindParam("emailPro_user", $emailPro_user,PDO::PARAM_STR);
                $mdp_user=hash('sha256',$data->mdp_user);
                $stmt1->bindParam("mdp_user", $mdp_user,PDO::PARAM_STR);
				$stmt1->bindParam("fonction_user", $fonction_user,PDO::PARAM_STR);
				$stmt1->bindParam("tel_user",$tel_user,PDO::PARAM_STR);
				$stmt1->bindParam("questSecr_user",$questSecr_user,PDO::PARAM_STR);
				$stmt1->bindParam("repSecr_user",$repSecr_user,PDO::PARAM_STR);
				$stmt1->bindParam("id_statut", $id_statut,PDO::PARAM_STR);
                $stmt1->execute();
                
                $userData=internalUserDetails($emailPro_user);
                
            }
            
            $db = null;
         

            if($userData){
               $userData = json_encode($userData);
                echo '{"userData": ' .$userData . '}';
            } else {
               echo '{"error":{"text":"Enter valid data"}}';
            }

           
        }
        else{
            echo '{"error":{"text":"Enter valid data"}}';
        }
    }
    catch(PDOException $e) {
        echo '{"error":{"text":'. $e->getMessage() .'}}';
    }
}
/*
function email() {
    $request = \Slim\Slim::getInstance()->request();
    $data = json_decode($request->getBody());
    $email=$data->email;

    try {
       
        $email_check = preg_match('~^[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.([a-zA-Z]{2,4})$~i', $email);
       
        if (strlen(trim($email))>0 && $email_check>0)
        {
            $db = getDB();
            $userData = '';
            $sql = "SELECT user_id FROM emailUsers WHERE email=:email";
            $stmt = $db->prepare($sql);
            $stmt->bindParam("email", $email,PDO::PARAM_STR);
            $stmt->execute();
            $mainCount=$stmt->rowCount();
            $created=time();
            if($mainCount==0)
            {*/
                
                /*Inserting user values
                $sql1="INSERT INTO emailUsers(email)VALUES(:email)";
                $stmt1 = $db->prepare($sql1);
                $stmt1->bindParam("email", $email,PDO::PARAM_STR);
                $stmt1->execute();
                
                
            }
            $userData=internalEmailDetails($email);
            $db = null;
            if($userData){
               $userData = json_encode($userData);
                echo '{"userData": ' .$userData . '}';
            } else {
               echo '{"error":{"text":"Enter valid dataaaa"}}';
            }
        }
        else{
            echo '{"error":{"text":"Enter valid data"}}';
        }
    }
    
    catch(PDOException $e) {
        echo '{"error":{"text":'. $e->getMessage() .'}}';
    }
}
*/

/* ### internal Username Details ### */
function internalUserDetails($input) {
    
    try {
        $db = getDB();
        $sql = "SELECT id_user, nom_user, emailPro_user, login_user FROM utilisateur WHERE login_user=:input or emailPro_user=:input";
        $stmt = $db->prepare($sql);
        $stmt->bindParam("input", $input,PDO::PARAM_STR);
        $stmt->execute();
        $usernameDetails = $stmt->fetch(PDO::FETCH_OBJ);
        $usernameDetails->token = apiToken($usernameDetails->id_user);
        $db = null;
        return $usernameDetails;
        
    } catch(PDOException $e) {
        echo '{"error":{"text":'. $e->getMessage() .'}}';
    }
    
}
?>

//{"login_user":"spotin123","nom_user":"Mr Potin","prenom_user":"Mr Stephane","emailPers_user":"pstephane@gmail.com","emailPro_user":"stephanepotin@ingerop.com","mdp_user":"spotin123","fonction_user":"DG","tel_user":"078123612","questSecr_user":"qui es tu?","repSecr_user":"Tu le seras un jour","id_statut":"2" }


/*

{
    "userData": {
        "id_user": "11",
        "login_user": "spotin123",
        "nom_user": "Mr Potin",
        "prenom_user": "Mr Stephane",
        "emailPers_user": "pstephane@gmail.com",
        "emailPro_user": "stephanepotin@ingerop.com",
        "mdp_user": "c7a716ddd2f104e70948a462a24ec62ab9c66ac2343eb5e9c55ff2c40bad171d",
        "fonction_user": "DG",
        "tel_user": "078123612",
        "questSecr_user": "qui es tu?",
        "repSecr_user": "Tu le seras un jour",
        "id_statut": "2",
        "token": "b4b675b2d9409b79fbede1ee041e59f010733049dd271ec4e968a555fc731ae5"
    }
}*/


//////////////////////////////////////////////////////////////////////////////

<?php
require 'config.php';
require 'Slim/Slim.php';

\Slim\Slim::registerAutoloader();
$app = new \Slim\Slim();

$app->post('/login','login'); /* User login */
$app->post('/signup','signup'); /* User Signup  */

$app->run();

/************************* USER LOGIN *************************************/
/* ### User login ### */
function login() {
    
    $request = \Slim\Slim::getInstance()->request();
    $data = json_decode($request->getBody());
    
    try {
        
        $db = getDB();
        $userData ='';
        $sql ="SELECT u.id_user,u.login_user,u.nom_user,u.prenom_user,u.emailPers_user,u.emailPro_user,
		u.mdp_user,u.fonction_user,u.tel_user,u.questSecr_user,u.repSecr_user,u.id_statut 
		FROM utilisateur u WHERE (u.login_user=:login_user or u.emailPers_user or u.emailPro_user=:login_user)and u.mdp_user=:mdp_user ";
        $stmt = $db->prepare($sql);
        $stmt->bindParam("login_user", $data->login_user, PDO::PARAM_STR);
        $mdp_user=hash('sha256',$data->mdp_user);
        $stmt->bindParam("mdp_user", mdp_user, PDO::PARAM_STR);
        $stmt->execute();
        $mainCount=$stmt->rowCount();
        $userData = $stmt->fetch(PDO::FETCH_OBJ);
        
        if(!empty($userData))
        {
            $id_user=$userData->id_user;
            $userData->token = apiToken($id_user);
        }
        
        $db = null;
         if($userData){
               $userData = json_encode($userData);
                echo '{"userData": ' .$userData . '}';
            } else {
               echo '{"error":{"text":"Bad request wrong login_user and mdp_user"}}';
            }

           
    }
    catch(PDOException $e) {
        echo '{"error":{"text":'. $e->getMessage() .'}}';
    }
}


/* ### User registration ### */
function signup(){
    $request = \Slim\Slim::getInstance()->request();
    $data = json_decode($request->getBody());
	$login_user=$data->login_user;
	$nom_user=$data->nom_user;
	$prenom_user=$data->prenom_user;
    $emailPro_user=$data->emailPro_user;
	$emailPers_user=$data->emailPers_user;
	$mdp_user=$data->mdp_user;
	$fonction_user=$data->fonction_user;
	$tel_user=$data->tel_user;
	$questSecr_user=$data->questSecr_user;
	$repSecr_user=$data->repSecr_user;
	$id_statut=$data->id_statut;
	
    try{       
        $login_user_check=preg_match('~^[A-Za-z0-9_]{3,20}$~i', $login_user);
        $emailPro_user_check=preg_match('~^[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.([a-zA-Z]{2,4})$~i',$emailPro_user);
		$emailPers_user_check=preg_match('~^[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.([a-zA-Z]{2,4})$~i',$emailPers_user);
        $mdp_user_check=preg_match('~^[A-Za-z0-9!@#$%^&*()_]{6,20}$~i', $mdp_user);
        
        echo $emailPers_user_check.'<br/>';
		echo $emailPers_user.'<br/>';
		echo $emailPro_user_check.'<br/>';
		echo $emailPro_user.'<br/>';
        
        if(strlen(trim($login_user))>0&&strlen(trim($mdp_user))>0&&strlen(trim($emailPers_user))>0&&strlen(trim($emailPro_user))>0&&$login_user_check>0&&$mdp_user_check>0&&$emailPro_user_check>0&&$emailPers_user_check>0)
		{   echo 'here';
            $db = getDB();
            $userData = '';
            $sql = "SELECT u.id_user FROM utilisateur u WHERE u.login_user=:login_user or u.emailPers_user or u.emailPro_user=:emailPro_user";
            $stmt = $db->prepare($sql);
            $stmt->bindParam("login_user", $login_user,PDO::PARAM_STR);
            $stmt->bindParam("emailPro_user", $emailPro_user,PDO::PARAM_STR);
			$stmt->bindParam("emailPers_user", $emailPers_user,PDO::PARAM_STR);
            $stmt->execute();
            $mainCount=$stmt->rowCount();
            $created=time();
			
            if($mainCount==0)
			{
                /*Inserting user values*/
        $sql1='INSERT INTO utilisateur u(u.login_user,u.nom_user,u.prenom_user,u.emailPers_user,u.emailPro_user,u.mdp_user,u.fonction_user,u.tel_user,u.questSecr_user,u.repSecr_user,u.id_statut) VALUES(:login_user,:nom_user,:prenom_user,:emailPers_user,:emailPro_user,:mdp_user,:fonction_user,:tel_user,:questSecr_user,:repSecr_user,:id_statut)';
                $stmt1 = $db->prepare($sql1);
                $stmt1->bindParam("login_user", $login_user,PDO::PARAM_STR);
				$stmt1->bindParam("nom_user",$nom_user,PDO::PARAM_STR);
				$stmt1->bindParam("prenom_user",$prenom_user,PDO::PARAM_STR);
				$stmt1->bindParam("emailPers_user",$emailPers_user,PDO::PARAM_STR);
				$stmt1->bindParam("emailPro_user", $emailPro_user,PDO::PARAM_STR);
                $mdp_user=hash('sha256',$data->mdp_user);
                $stmt1->bindParam("mdp_user", $mdp_user,PDO::PARAM_STR);
				$stmt1->bindParam("fonction_user", $fonction_user,PDO::PARAM_STR);
				$stmt1->bindParam("tel_user",$tel_user,PDO::PARAM_STR);
				$stmt1->bindParam("questSecr_user",$questSecr_user,PDO::PARAM_STR);
				$stmt1->bindParam("repSecr_user",$repSecr_user,PDO::PARAM_STR);
				$stmt1->bindParam("id_statut", $id_statut,PDO::PARAM_STR);
                $stmt1->execute();
                $userData=internalUserDetails($emailPro_user); 
            } 
            $db = null;
           if($userData){
               $userData = json_encode($userData);
                echo '{"userData":'.$userData.'}';
            } else {
               echo'{"error":{"text":"Enter valid data"}}';
            }
        }
        else{
            echo '{"error":{"text":"Données non corresponantes"}}';
        }
    }
    catch(PDOException $e) {
        echo '{"error":{"text":'. $e->getMessage() .'}}';
    }
}
/**
function email() {
    $request = \Slim\Slim::getInstance()->request();
    $data = json_decode($request->getBody());
    $emailPro_user=$data->emailPro_user;

    try {
       
        $email_check = preg_match('~^[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.([a-zA-Z]{2,4})$~i', $emailPro_user);
       
        if (strlen(trim($email))>0 && $email_check>0)
        {
            $db = getDB();
            $userData = '';
            $sql = "SELECT id_user FROM utilisateur WHERE emailPro_user=:emailPro_user";
            $stmt = $db->prepare($sql);
            $stmt->bindParam("emailPro_user", $emailPro_user,PDO::PARAM_STR);
            $stmt->execute();
            $mainCount=$stmt->rowCount();
            $created=time();
            if($mainCount==0)
            {
               **/ 
                /*Inserting user values*/
              /**  $sql1="INSERT INTO emailUsers(email)VALUES(:email)";
                $stmt1 = $db->prepare($sql1);
                $stmt1->bindParam("email", $email,PDO::PARAM_STR);
                $stmt1->execute();
                
                
            }
            $userData=internalEmailDetails($email);
            $db = null;
            if($userData){
               $userData = json_encode($userData);
                echo '{"userData": ' .$userData . '}';
            } else {
               echo '{"error":{"text":"Enter valid dataaaa"}}';
            }
        }
        else{
            echo '{"error":{"text":"Enter valid data"}}';
        }
    }
    
    catch(PDOException $e) {
        echo '{"error":{"text":'. $e->getMessage() .'}}';
    }
}
**/

/* ### internal Username Details ### */
function internalUserDetails($input) {
    
    try {
        $db = getDB();
        $sql ="SELECT u.id_user,u.login_user,u.nom_user,u.prenom_user,u.emailPers_user,u.emailPro_user,u.mdp_user,u.fonction_user,u.tel_user,u.questSecr_user,u.repSecr_user,u.id_statut FROM utilisateur u WHERE u.login_user=:input or u.emailPro_user=:input or u.emailPers_user=:input";
        $stmt = $db->prepare($sql);
        $stmt->bindParam("input",$input,PDO::PARAM_STR);
        $stmt->execute();
        $usernameDetails = $stmt->fetch(PDO::FETCH_OBJ);
        $usernameDetails->token = apiToken($usernameDetails->id_user);
        $db = null;
        return $usernameDetails;  
    } catch(PDOException $e) {
        echo '{"error":{"text":'. $e->getMessage() .'}}';
    }  
}
?>

////////////////////////

<?php
require 'config.php';
require 'Slim/Slim.php';

\Slim\Slim::registerAutoloader();
$app = new \Slim\Slim();

$app->post('/login','login'); /* User login */
$app->post('/signup','signup'); /* User Signup  */

$app->run();

/************************* USER LOGIN *************************************/
/* ### User login ### */
function login() {
    
    $request = \Slim\Slim::getInstance()->request();
    $data = json_decode($request->getBody());
    
    try {
        
        $db = getDB();
        $userData ='';
        $sql ="SELECT u.id_user,u.login_user,u.nom_user,u.prenom_user,u.emailPers_user,u.emailPro_user,
		u.mdp_user,u.fonction_user,u.tel_user,u.questSecr_user,u.repSecr_user,u.id_statut 
		FROM utilisateur u WHERE (u.login_user=:login_user or u.emailPers_user or u.emailPro_user=:login_user)and u.mdp_user=:mdp_user ";
        $stmt = $db->prepare($sql);
        $stmt->bindParam("login_user", $data->login_user, PDO::PARAM_STR);
        $mdp_user=hash('sha256',$data->mdp_user);
        $stmt->bindParam("mdp_user", mdp_user, PDO::PARAM_STR);
        $stmt->execute();
        $mainCount=$stmt->rowCount();
        $userData = $stmt->fetch(PDO::FETCH_OBJ);
        
        if(!empty($userData))
        {
            $id_user=$userData->id_user;
            $userData->token = apiToken($id_user);
        }
        
        $db = null;
         if($userData){
               $userData = json_encode($userData);
                echo '{"userData": ' .$userData . '}';
            } else {
               echo '{"error":{"text":"Bad request wrong login_user and mdp_user"}}';
            }

           
    }
    catch(PDOException $e) {
        echo '{"error":{"text":'. $e->getMessage() .'}}';
    }
}


/* ### User registration ### */
function signup(){
	
    $request = \Slim\Slim::getInstance()->request();
    $data = json_decode($request->getBody());
	
	$login_user=$data->login_user;
	$nom_user=$data->nom_user;
	$prenom_user=$data->prenom_user;
	$emailPers_user=$data->emailPers_user;
    $emailPro_user=$data->emailPro_user;
	$mdp_user=$data->mdp_user;
	$fonction_user=$data->fonction_user;
	$tel_user=$data->tel_user;
	$questSecr_user=$data->questSecr_user;
	$repSecr_user=$data->repSecr_user;
	$id_statut=$data->id_statut;
	
    try{       
        $login_user_check=preg_match('~^[A-Za-z0-9_]{3,20}$~i', $login_user);
		$emailPers_user_check=preg_match('~^[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.([a-zA-Z]{2,4})$~i',$emailPers_user);
		$emailPro_user_check=preg_match('~^[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.([a-zA-Z]{2,4})$~i',$emailPro_user);
        $mdp_user_check=preg_match('~^[A-Za-z0-9!@#$%^&*()_]{6,20}$~i', $mdp_user);
        /*
        echo $emailPers_user_check.'<br/>';
		echo $emailPers_user.'<br/>';
		echo $emailPro_user_check.'<br/>';
		echo $emailPro_user.'<br/>';*/
     
        if(strlen(trim($login_user))>0&&strlen(trim($mdp_user))>0&&$login_user_check>0&&$emailPers_user_check>0&&$emailPro_user_check>0&&$mdp_user_check>0)
		{   echo 'here';
            $db = getDB();
            $userData = '';
            /*$sql = "SELECT u.id_user FROM utilisateur u WHERE u.login_user=:login_user or u.emailPers_user or u.emailPro_user=:emailPro_user";
            $stmt = $db->prepare($sql);
            $stmt->bindParam("login_user", $login_user,PDO::PARAM_STR);
            $stmt->bindParam("emailPro_user", $emailPro_user,PDO::PARAM_STR);
			$stmt->bindParam("emailPers_user", $emailPers_user,PDO::PARAM_STR);
            $stmt->execute();
            $mainCount=$stmt->rowCount();
            $created=time();
			
            if($mainCount==0)
			{*/
                /*Inserting user values*/
        $sql1='INSERT INTO utilisateur u(u.login_user,u.nom_user,u.prenom_user,u.emailPers_user,u.emailPro_user,u.mdp_user,u.fonction_user,u.tel_user,u.questSecr_user,u.repSecr_user,u.id_statut) VALUES(:login_user,:nom_user,:prenom_user,:emailPers_user,:emailPro_user,:mdp_user,:fonction_user,:tel_user,:questSecr_user,:repSecr_user,:id_statut)';
                $stmt1 = $db->prepare($sql1);
                $stmt1->bindParam("login_user", $login_user,PDO::PARAM_STR);
				$stmt1->bindParam("nom_user",$nom_user,PDO::PARAM_STR);
				$stmt1->bindParam("prenom_user",$prenom_user,PDO::PARAM_STR);
				$stmt1->bindParam("emailPers_user",$emailPers_user,PDO::PARAM_STR);
				$stmt1->bindParam("emailPro_user", $emailPro_user,PDO::PARAM_STR);
                $mdp_user=hash('sha256',$data->mdp_user);
                $stmt1->bindParam("mdp_user", $mdp_user,PDO::PARAM_STR);
				$stmt1->bindParam("fonction_user", $fonction_user,PDO::PARAM_STR);
				$stmt1->bindParam("tel_user",$tel_user,PDO::PARAM_STR);
				$stmt1->bindParam("questSecr_user",$questSecr_user,PDO::PARAM_STR);
				$stmt1->bindParam("repSecr_user",$repSecr_user,PDO::PARAM_STR);
				$stmt1->bindParam("id_statut", $id_statut,PDO::PARAM_STR);
                $stmt1->execute();
                $userData=internalUserDetails($emailPro_user); 
            //} 
            //$db = null;
           if($userData){
               $userData = json_encode($userData);
                echo '{"userData":'.$userData.'}';
            } else {
               echo'{"error":{"text":"Enter valid data"}}';
            }
        }
        else{
            echo '{"error":{"text":"Données non corresponantes"}}';
        }
    }
    catch(PDOException $e) {
        echo '{"error":{"text":'. $e->getMessage() .'}}';
    }
}
/**
function email() {
    $request = \Slim\Slim::getInstance()->request();
    $data = json_decode($request->getBody());
    $emailPro_user=$data->emailPro_user;

    try {
       
        $email_check = preg_match('~^[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.([a-zA-Z]{2,4})$~i', $emailPro_user);
       
        if (strlen(trim($email))>0 && $email_check>0)
        {
            $db = getDB();
            $userData = '';
            $sql = "SELECT id_user FROM utilisateur WHERE emailPro_user=:emailPro_user";
            $stmt = $db->prepare($sql);
            $stmt->bindParam("emailPro_user", $emailPro_user,PDO::PARAM_STR);
            $stmt->execute();
            $mainCount=$stmt->rowCount();
            $created=time();
            if($mainCount==0)
            {
               **/ 
                /*Inserting user values*/
              /**  $sql1="INSERT INTO emailUsers(email)VALUES(:email)";
                $stmt1 = $db->prepare($sql1);
                $stmt1->bindParam("email", $email,PDO::PARAM_STR);
                $stmt1->execute();
                
                
            }
            $userData=internalEmailDetails($email);
            $db = null;
            if($userData){
               $userData = json_encode($userData);
                echo '{"userData": ' .$userData . '}';
            } else {
               echo '{"error":{"text":"Enter valid dataaaa"}}';
            }
        }
        else{
            echo '{"error":{"text":"Enter valid data"}}';
        }
    }
    
    catch(PDOException $e) {
        echo '{"error":{"text":'. $e->getMessage() .'}}';
    }
}
**/

/* ### internal Username Details ### */
function internalUserDetails($input) {
    
    try {
        $db = getDB();
        $sql ="SELECT u.id_user,u.login_user,u.nom_user,u.prenom_user,u.emailPers_user,u.emailPro_user,u.mdp_user,u.fonction_user,u.tel_user,u.questSecr_user,u.repSecr_user,u.id_statut FROM utilisateur u WHERE u.login_user=:input or u.emailPro_user=:input or u.emailPers_user=:input";
        $stmt = $db->prepare($sql);
        $stmt->bindParam("input",$input,PDO::PARAM_STR);
        $stmt->execute();
        $usernameDetails = $stmt->fetch(PDO::FETCH_OBJ);
        $usernameDetails->token = apiToken($usernameDetails->id_user);
        $db = null;
        return $usernameDetails;  
    } catch(PDOException $e) {
        echo '{"error":{"text":'. $e->getMessage() .'}}';
    }  
}
?>


